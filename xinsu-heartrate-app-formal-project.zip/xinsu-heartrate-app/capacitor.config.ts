
import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.xinsu.heartrate',
  appName: 'xinsu-heartrate-app',
  webDir: 'dist'
};

export default config;
