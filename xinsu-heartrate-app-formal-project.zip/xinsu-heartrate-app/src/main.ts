
import { initializeApp } from './app/bootstrap';

initializeApp();
