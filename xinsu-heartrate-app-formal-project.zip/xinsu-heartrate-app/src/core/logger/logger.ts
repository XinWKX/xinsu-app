
export class Logger {
    private logs:string[] = [];

    info(message:string){
        this.write('INFO', message);
    }

    warn(message:string){
        this.write('WARN', message);
    }

    error(message:string){
        this.write('ERROR', message);
    }

    fatal(message:string){
        this.write('FATAL', message);
    }

    private write(level:string, message:string){
        const line = `[${new Date().toISOString()}] [${level}] ${message}`;
        this.logs.push(line);
        console.log(line);

        try{
            localStorage.setItem(
                'xinsu_logs',
                JSON.stringify(this.logs)
            );
        }catch(e){
            console.error(e);
        }
    }

    async exportLogs(){
        const content = localStorage.getItem('xinsu_logs') || '';
        const blob = new Blob([content], {type:'text/plain'});
        const url = URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.href = url;
        a.download = 'xinsu-heartrate-app-log.txt';
        a.click();

        URL.revokeObjectURL(url);
    }
}
