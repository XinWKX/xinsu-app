
import { Logger } from '../core/logger/logger';
import { HeartbeatEngine } from '../audio/heartbeat-engine';

const logger = new Logger();
const heartbeat = new HeartbeatEngine();

export function initializeApp() {
    logger.info('App bootstrap started');

    const bpmEl = document.getElementById('bpm') as HTMLElement;

    const demoBtn = document.getElementById('demoBtn');
    const exportBtn = document.getElementById('exportBtn');

    demoBtn?.addEventListener('click', () => {
        const bpm = 72;
        bpmEl.innerText = String(bpm);
        heartbeat.updateBPM(bpm);
        logger.info('Demo mode started');
    });

    exportBtn?.addEventListener('click', async () => {
        await logger.exportLogs();
    });

    logger.info('UI initialized');
}
