
export class HeartbeatEngine {
    private audioContext: AudioContext | null = null;
    private timer:any = null;
    private currentBPM:number = 0;

    updateBPM(bpm:number){
        if(bpm === this.currentBPM) return;

        this.currentBPM = bpm;

        if(this.timer){
            clearInterval(this.timer);
        }

        if(!this.audioContext){
            this.audioContext = new AudioContext({
                latencyHint:'interactive'
            });
        }

        const interval = 60000 / bpm;

        const playBeat = () => {
            if(!this.audioContext) return;

            const osc = this.audioContext.createOscillator();
            const gain = this.audioContext.createGain();

            osc.frequency.value = 85;
            gain.gain.value = 0.15;

            osc.connect(gain);
            gain.connect(this.audioContext.destination);

            osc.start();

            setTimeout(() => {
                osc.stop();
            }, 70);
        };

        playBeat();

        this.timer = setInterval(() => {
            playBeat();
        }, interval);
    }
}
