
# xinsu-heartrate-app

正式版 Android 心率监护应用工程。

当前版本包含：

- TypeScript 架构
- Heartbeat Engine
- Logger System
- 模块化结构
- GitHub Actions
- Capacitor 配置
- APK 构建基础结构

后续继续加入：

- 原生 BLE
- Recovery System
- Safe Mode
- Android Lifecycle
