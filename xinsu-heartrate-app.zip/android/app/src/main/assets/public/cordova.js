

// ===== Native Heartbeat Engine =====
let heartbeatTimer = null;
let currentBPM = 75;

const audioContext = new (window.AudioContext || window.webkitAudioContext)({
  latencyHint: 'interactive'
});

function playHeartbeatClick() {
  const osc = audioContext.createOscillator();
  const gain = audioContext.createGain();

  osc.type = 'triangle';
  osc.frequency.value = 90;

  gain.gain.setValueAtTime(0.18, audioContext.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.06);

  osc.connect(gain);
  gain.connect(audioContext.destination);

  osc.start();
  osc.stop(audioContext.currentTime + 0.06);
}

function restartHeartbeatLoop(bpm) {
  currentBPM = bpm;

  if (heartbeatTimer) {
    clearInterval(heartbeatTimer);
  }

  const interval = 60000 / bpm;

  heartbeatTimer = setInterval(() => {
    playHeartbeatClick();
  }, interval);
}

window.restartHeartbeatLoop = restartHeartbeatLoop;


// ===== Native BLE =====
import { BluetoothLe } from '@capacitor-community/bluetooth-le';

window.connectHeartRateDevice = async function() {
  try {
    await BluetoothLe.initialize();

    const device = await BluetoothLe.requestDevice({
      services: ['180d']
    });

    await BluetoothLe.connect({
      deviceId: device.deviceId
    });

    await BluetoothLe.startNotifications(
      {
        deviceId: device.deviceId,
        service: '180d',
        characteristic: '2a37'
      },
      (value) => {
        try {
          const data = new Uint8Array(value.buffer || value);

          let bpm = data[1];

          if (!bpm || bpm < 30 || bpm > 240) {
            return;
          }

          restartHeartbeatLoop(bpm);

          if (window.updateHeartRate) {
            window.updateHeartRate(bpm);
          }

        } catch(e) {
          console.error(e);
        }
      }
    );

  } catch(e) {
    console.error("BLE CONNECT ERROR:", e);
    alert("蓝牙连接失败: " + e.message);
  }
};
