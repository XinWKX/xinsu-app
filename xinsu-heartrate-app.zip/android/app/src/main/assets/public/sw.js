const CACHE_NAME = 'xinsu-v1';
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Service Worker: Caching assets');
        return cache.addAll(ASSETS_TO_CACHE);
      })
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cache) => {
          if (cache !== CACHE_NAME) {
            console.log('Service Worker: Clearing old cache');
            return caches.delete(cache);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  
  if (event.request.url.includes('fonts.googleapis.com') || 
      event.request.url.includes('fonts.gstatic.com')) {
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        if (cachedResponse) {
          return cachedResponse;
        }
        return fetch(event.request).then((response) => {
          if (!response || response.status !== 200 || response.type !== 'basic') {
            return response;
          }
          const responseToCache = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache);
          });
          return response;
        });
      })
    );
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse;
      }

      return fetch(event.request).then((response) => {
        if (!response || response.status !== 200 || response.type !== 'basic') {
          return response;
        }

        const responseToCache = response.clone();
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(event.request, responseToCache);
        });

        return response;
      }).catch(() => {
        if (event.request.destination === 'document') {
          return caches.match('/index.html');
        }
        return new Response('Offline', { status: 503 });
      });
    })
  );
});


// ===== Native Heartbeat Engine =====
let heartbeatTimer = null;
let currentBPM = 75;

const audioContext = new (window.AudioContext || window.webkitAudioContext)({
  latencyHint: 'interactive'
});

function playHeartbeatClick() {
  const osc = audioContext.createOscillator();
  const gain = audioContext.createGain();

  osc.type = 'triangle';
  osc.frequency.value = 90;

  gain.gain.setValueAtTime(0.18, audioContext.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.06);

  osc.connect(gain);
  gain.connect(audioContext.destination);

  osc.start();
  osc.stop(audioContext.currentTime + 0.06);
}

function restartHeartbeatLoop(bpm) {
  currentBPM = bpm;

  if (heartbeatTimer) {
    clearInterval(heartbeatTimer);
  }

  const interval = 60000 / bpm;

  heartbeatTimer = setInterval(() => {
    playHeartbeatClick();
  }, interval);
}

window.restartHeartbeatLoop = restartHeartbeatLoop;


// ===== Native BLE =====
import { BluetoothLe } from '@capacitor-community/bluetooth-le';

window.connectHeartRateDevice = async function() {
  try {
    await BluetoothLe.initialize();

    const device = await BluetoothLe.requestDevice({
      services: ['180d']
    });

    await BluetoothLe.connect({
      deviceId: device.deviceId
    });

    await BluetoothLe.startNotifications(
      {
        deviceId: device.deviceId,
        service: '180d',
        characteristic: '2a37'
      },
      (value) => {
        try {
          const data = new Uint8Array(value.buffer || value);

          let bpm = data[1];

          if (!bpm || bpm < 30 || bpm > 240) {
            return;
          }

          restartHeartbeatLoop(bpm);

          if (window.updateHeartRate) {
            window.updateHeartRate(bpm);
          }

        } catch(e) {
          console.error(e);
        }
      }
    );

  } catch(e) {
    console.error("BLE CONNECT ERROR:", e);
    alert("蓝牙连接失败: " + e.message);
  }
};
