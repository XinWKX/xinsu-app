package com.xinsu.heartrate;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
